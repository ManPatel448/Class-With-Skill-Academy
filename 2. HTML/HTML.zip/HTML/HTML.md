what is http?
what is client and server?
Difference between front end and backend.
what is HTML?
what is tag in html?
    Tag is a format in which we write our content.

Tags types
   opening and closing tags
      heading tags---h1,h2,h3,h4,h5,h6
      div
      p
      section
      article
      span
  Block vs inline tags
  self contained tags/ opening tags

